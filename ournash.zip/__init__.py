import numpy as np
import matplotlib.pyplot as plt
from decimal import *
from fractions import Fraction
from .nash import main
